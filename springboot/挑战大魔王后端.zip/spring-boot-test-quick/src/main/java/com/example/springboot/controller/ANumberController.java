package com.example.springboot.controller;

import com.example.springboot.dao.ANumberRepository;
import com.example.springboot.dto.ANumber;
import com.example.springboot.service.ANumberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/aNumber")
public class ANumberController {
    @Autowired
    private ANumberRepository aNumberRepository;
    @Autowired
    public ANumberService aNumberService;
    @ResponseBody
    @RequestMapping("/getAll")
    public List<ANumber> getAll(){
        return aNumberService.findAll();
    }
}
