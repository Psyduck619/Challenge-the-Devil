package com.example.springboot.controller;

import com.example.springboot.dto.AAttention;
import com.example.springboot.service.AAttentionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/aAttention")
public class AAttentionController {
    @Autowired
    public AAttentionService aAttentionService;
    @ResponseBody
    @RequestMapping("/getAll")
    public List<AAttention> getAll() {
        return aAttentionService.finAll();
    }
}
