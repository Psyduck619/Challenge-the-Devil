package com.example.springboot.dto;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

@Entity
@Table(name = "history")
public class History implements Serializable {
    private static final long serialVersionUID = 1L;
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;

    @Column(name = "userid")
    private String userId;

    @Column(name = "level")
    private int level ;

    @Column(name = "starttime")
    private Timestamp startTime;

    @Column(name = "finishtime")
    private Timestamp finishTime;

    @Column(name = "timescore")
    private int timescore;

    @Column(name = "comment1")
    private String comment1;

    @Column(name = "comment2")
    private String comment2;
    @Column(name = "comment3")
    private String comment3;

    @Column(name = "comment4")
    private String comment4;

    @Column(name = "score1")
    private float score1;

    @Column(name = "score2")
    private float score2;

    @Column(name = "score3")
    private float score3;

    @Column(name = "score4")
    private float score4;

    @Column(name = "score5")
    private float score5;

    @Column(name = "score6")
    private float score6;

    @Column(name = "score7")
    private float score7;

    @Column(name = "score8")
    private float score8;
    
    @Column(name = "score9")
    private float score9;

    public History() {

    }

    public History(int id, String userId) {
        this.id = id;
        this.userId = userId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Timestamp finishTime) {
        this.finishTime = finishTime;
    }

    public int getTimescore() {
        return timescore;
    }

    public void setTimescore(int timescore) {
        this.timescore = timescore;
    }

    public String getComment1() {
        return comment1;
    }

    public void setComment1(String comment1) {
        this.comment1 = comment1;
    }

    public String getComment2() {
        return comment2;
    }

    public void setComment2(String comment2) {
        this.comment2 = comment2;
    }

    public String getComment3() {
        return comment3;
    }

    public void setComment3(String comment3) {
        this.comment3 = comment3;
    }

    public String getComment4() {
        return comment4;
    }

    public void setComment4(String comment4) {
        this.comment4 = comment4;
    }

    public float getScore1() {
        return score1;
    }

    public void setScore1(float score1) {
        this.score1 = score1;
    }

    public float getScore2() {
        return score2;
    }

    public void setScore2(float score2) {
        this.score2 = score2;
    }

    public float getScore3() {
        return score3;
    }

    public void setScore3(float score3) {
        this.score3 = score3;
    }

    public float getScore4() {
        return score4;
    }

    public void setScore4(float score4) {
        this.score4 = score4;
    }

    public float getScore5() {
        return score5;
    }

    public void setScore5(float score5) {
        this.score5 = score5;
    }

    public float getScore6() {
        return score6;
    }

    public void setScore6(float score6) {
        this.score6 = score6;
    }

    public float getScore7() {
        return score7;
    }

    public void setScore7(float score7) {
        this.score7 = score7;
    }

    public float getScore8() {
        return score8;
    }

    public void setScore8(float score8) {
        this.score8 = score8;
    }

    public float getScore9() {
        return score9;
    }

    public void setScore9(float score9) {
        this.score9 = score9;
    }
}
