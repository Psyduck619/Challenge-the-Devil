package com.example.springboot.controller;

import com.example.springboot.dao.UserCommentRepository;
import com.example.springboot.dto.History;
import com.example.springboot.dto.UserComment;
import com.example.springboot.service.UserCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/contact")
public class UserCommentController {
    @Autowired
    private UserCommentService userCommentService;
    @Autowired
    public UserCommentRepository userCommentRepository;
    @ResponseBody
    @RequestMapping("/contactinfo")
    public Map getAll(){
        Map map = new HashMap();
        List<UserComment> userComments = userCommentService.findAll();
        if (userComments != null) {
            map.put("code", 200);
            map.put("result", "用户评价列表获取成功");
            map.put("list", userComments);
        } else {
            map.put("code", 0);
            map.put("result", "用户评价列表获取失败");
        }
        return map;
    }

    @ResponseBody
    @PostMapping("/upcontact")
    public Map upUserinfo(@RequestParam("openid") String openid, @RequestParam("content") String content) {
        Map map = new HashMap();
        UserComment userComment = new UserComment();
        userComment.setUserId(openid);
        userComment.setContent(content);
        if (userCommentRepository.save(userComment) != null) {
            map.put("code", 200);
            map.put("result", "用户反馈上传成功");
            System.out.println(openid + "用户建议上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "用户反馈上传失败");
            System.out.println(openid + "用户建议上传失败");
        }
        return map;
    }
}
