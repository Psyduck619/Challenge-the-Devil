package com.example.springboot.dto;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity//标注位实体类
@Table(name = "iot")//对应数据库的表
public class IoT {

    private static final long serialVersionUID = 1L;
    @Id//主键注解
    @Column(name = "id")
    private int id;
    @Column(name = "client")
    private String client;
    @Column(name = "temp")
    private float temp;
    @Column(name = "humidity")
    private float humidity;
    @Column(name = "time")
    private Timestamp time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public float getTemp() {
        return temp;
    }

    public void setTemp(float temp) {
        this.temp = temp;
    }

    public float getHumidity() {
        return humidity;
    }

    public void setHumidity(float humidity) {
        this.humidity = humidity;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }
}
