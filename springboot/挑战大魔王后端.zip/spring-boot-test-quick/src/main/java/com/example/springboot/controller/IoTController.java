package com.example.springboot.controller;

import com.example.springboot.dao.IoTRepository;
import com.example.springboot.dto.IoT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/iot")
public class IoTController {
    @Autowired
    public IoTRepository ioTRepository;

    @ResponseBody
    @RequestMapping("/getAll")
    public Map getAll(){
        Map map = new HashMap();
        List<IoT> msg = ioTRepository.findAll();
        if (msg != null) {
            map.put("code", 200);
            map.put("result", "成功");
            map.put("list", msg);
        } else {
            map.put("code", 0);
            map.put("result", "失败");
        }
        return map;
    }

}
