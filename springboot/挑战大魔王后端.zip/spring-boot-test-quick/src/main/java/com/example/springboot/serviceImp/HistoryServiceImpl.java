package com.example.springboot.serviceImp;

import com.example.springboot.dao.HistoryRepository;
import com.example.springboot.dto.History;
import com.example.springboot.service.HistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistoryServiceImpl implements HistoryService {
    @Autowired
    private HistoryRepository historyRepository;//注入Dao层
    @Override
    public List<History> findAll() {
        return historyRepository.findAll();
    }
    public List<History> findByUserId(String openId) {
        return historyRepository.findByUserId(openId);
    }
    public History findById(int id) {
        return historyRepository.findById(id);
    }
}
