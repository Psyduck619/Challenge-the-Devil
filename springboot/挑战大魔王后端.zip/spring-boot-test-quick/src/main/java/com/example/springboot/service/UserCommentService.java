package com.example.springboot.service;

import com.example.springboot.dto.UserComment;

import java.util.List;

public interface UserCommentService {
    List<UserComment> findAll();
}
