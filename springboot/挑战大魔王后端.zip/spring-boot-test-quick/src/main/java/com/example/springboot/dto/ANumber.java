package com.example.springboot.dto;

import javax.persistence.*;

@Entity
@Table(name = "A_number")
public class ANumber {

    private static final long serialVersionUID = 1L;
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "num")
    private String num;
    @Column(name = "keynum")
    private String keyNum;

    public ANumber() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getKeyNum() {
        return keyNum;
    }

    public void setKeyNum(String keyNum) {
        this.keyNum = keyNum;
    }
}
