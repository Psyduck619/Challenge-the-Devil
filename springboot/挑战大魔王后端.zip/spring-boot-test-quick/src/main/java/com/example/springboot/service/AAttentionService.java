package com.example.springboot.service;

import com.example.springboot.dto.AAttention;

import java.util.List;

public interface AAttentionService {
    List<AAttention> finAll();
}
