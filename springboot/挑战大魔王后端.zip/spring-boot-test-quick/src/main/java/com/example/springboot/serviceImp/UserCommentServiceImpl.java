package com.example.springboot.serviceImp;

import com.example.springboot.dao.UserCommentRepository;
import com.example.springboot.dto.UserComment;
import com.example.springboot.service.UserCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserCommentServiceImpl implements UserCommentService {
    @Autowired
    private UserCommentRepository userCommentRepository;//注入Dao层
    @Override
    public List<UserComment> findAll() {
        return userCommentRepository.findAll();
    }
}
