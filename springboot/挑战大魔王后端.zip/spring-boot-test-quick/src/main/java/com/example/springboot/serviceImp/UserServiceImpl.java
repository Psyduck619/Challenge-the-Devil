package com.example.springboot.serviceImp;

import com.example.springboot.dao.UserRepository;
import com.example.springboot.dto.User;
import com.example.springboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;//注入Dao层
    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }
    public User findByWxId(String wxId) {
        return userRepository.findByWxId(wxId);
    }
}
