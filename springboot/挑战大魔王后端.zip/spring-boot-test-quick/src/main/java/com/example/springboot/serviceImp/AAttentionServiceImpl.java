package com.example.springboot.serviceImp;

import com.example.springboot.dao.AAttentionRepository;
import com.example.springboot.dto.AAttention;
import com.example.springboot.service.AAttentionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AAttentionServiceImpl implements AAttentionService {
    @Autowired
    private AAttentionRepository aAttentionRepository;
    @Override
    public List<AAttention> finAll() {
        return aAttentionRepository.findAll();
    }
}
