package com.example.springboot.controller;

import com.example.springboot.dao.UserRepository;
import com.example.springboot.dto.User;
import com.example.springboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.jws.soap.SOAPBinding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    public UserRepository userRepository;

    //查询所有用户
    @ResponseBody
    @RequestMapping("/userinfo")
    public Map getAll(){
        Map map = new HashMap();
        List<User> users = userService.findAll();
        if (users != null) {
            map.put("code", 200);
            map.put("result", "用户列表获取成功");
            map.put("list", users);
        } else {
            map.put("code", 0);
            map.put("result", "用户列表获取失败");
        }
        return map;
    }

    //根据openid查询用户
    @ResponseBody
    @RequestMapping("/byopenid")
    public Map getByOpenId(@RequestParam("openid") String openid){
        Map map = new HashMap();
        User user = userService.findByWxId(openid);
        if (user != null) {
            map.put("code", 200);
            map.put("result", "用户获取成功");
            map.put("list", user);
        } else {
            map.put("code", 0);
            map.put("result", "用户获取失败");
        }
        return map;
    }

    //登录
    @ResponseBody
    @PostMapping("/upUserinfo")
    public Map upUserinfo(@RequestParam("openid") String openid, @RequestParam("name") String wxName) {
        Map map = new HashMap();
        User user = null;
        if (userService.findByWxId(openid) == null) {
            user = new User();
            user.setWxId(openid);
            user.setWxName(wxName);
        } else {
            user = userService.findByWxId(openid);
        }
        if (userRepository.save(user) != null) {
            map.put("code", 200);
            map.put("result", "登录成功");
            System.out.println(openid + wxName + "用户数据上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "登录失败");
            System.out.println(openid + wxName + "用户数据上传失败");
        }
        return map;
    }
    //新增或更新孩子信息
    @ResponseBody
    @PostMapping("/updateUserinfo")
    public Map updateUserinfo(@RequestParam("openid") String openid, @RequestParam("magicName") String magicName,
                 @RequestParam("sex") int sex, @RequestParam("age") int age) {
        Map map = new HashMap();
        User user = userService.findByWxId(openid);
        user.setWxId(openid);
        user.setUserName(magicName);
        user.setSex(sex);
        user.setAge(age);
        System.out.println(openid + "魔法师信息更新成功!");
        if (userRepository.save(user) != null) {
            map.put("code", 200);
            map.put("result", "用户信息更新成功");
            System.out.println(openid + "用户信息更新成功");
        } else {
            map.put("code", 0);
            map.put("result", "用户信息更新失败");
            System.out.println(openid + "用户信息更新失败");
        }
        return map;
    }
}
