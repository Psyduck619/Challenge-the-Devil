package com.example.springboot.dao;

import com.example.springboot.dto.ANumber;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ANumberRepository extends JpaRepository<ANumber, String> {
    List<ANumber> findAll();
}
