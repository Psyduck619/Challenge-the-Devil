package com.example.springboot.serviceImp;

import com.example.springboot.dao.ANumberRepository;
import com.example.springboot.dto.ANumber;
import com.example.springboot.service.ANumberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ANumberServiceImpl implements ANumberService {
    @Autowired
    private ANumberRepository aNumberRepository;//注入Dao层
    @Override
    public List<ANumber> findAll() {
        return aNumberRepository.findAll();
    }
}
