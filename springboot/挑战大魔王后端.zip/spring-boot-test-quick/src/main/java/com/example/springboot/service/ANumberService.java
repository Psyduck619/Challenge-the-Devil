package com.example.springboot.service;

import com.example.springboot.dto.ANumber;

import java.util.List;

public interface ANumberService {
    List<ANumber> findAll();
}
