package com.example.springboot.controller;

import com.example.springboot.Data;
import com.example.springboot.dao.HistoryRepository;
import com.example.springboot.dto.History;
import com.example.springboot.service.HistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/history")
public class HistoryController {
    @Autowired
    private HistoryService historyService;
    @Autowired
    public HistoryRepository historyRepository;
    public final long TIME = 28800000;
    Data data = new Data();

    @ResponseBody
    @RequestMapping("/historyinfo")
    public Map getAll() {
        Map map = new HashMap();
        List<History> histories = historyService.findAll();
        if (histories != null) {
            map.put("code", 200);
            map.put("result", "游戏记录列表获取成功");
            map.put("list", histories);
        } else {
            map.put("code", 0);
            map.put("result", "游戏记录列表获取失败");
        }
        return map;
    }

    //根据用户查询
    @ResponseBody
    @RequestMapping("/byopenid")
    public Map byUserId(@RequestParam("openid") String openid) {
        Map map = new HashMap();
        List<History> list = historyService.findByUserId(openid);
        if (list != null) {
            map.put("code", 200);
            map.put("result", "用户游戏记录查询成功");
            map.put("list", list);
        } else {
            map.put("code", 0);
            map.put("result", "用户游戏记录查询失败");
        }
        return map;
    }

    //根据游戏id查询
    @ResponseBody
    @RequestMapping("/bygameid")
    public Map byGameId(@RequestParam("id") int id) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        if (history != null) {
            map.put("code", 200);
            map.put("result", "游戏详情查询成功");
            map.put("list", history);
        } else {
            map.put("code", 0);
            map.put("result", "游戏详情查询失败");
        }
        return map;
    }

    //初始化游戏记录
    @ResponseBody
    @PostMapping("/upinfo") //游戏开始，上传基本信息，新建记录
    public Map upHistoryInfo(@RequestParam("openid") String openid, @RequestParam("age") int age) {
        Map map = new HashMap();
        History history = new History();
        history.setUserId(openid);
        history.setLevel(age >= 11 ? 2 : 1);
        history.setStartTime(new Timestamp(System.currentTimeMillis() + TIME));
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏初始化成功");
            map.put("list", history);
        } else {
            map.put("code", 0);
            map.put("result", "游戏初始化失败");
        }
        return map;
    }

    //上传分数1
    @ResponseBody
    @PostMapping("/upscore1")
    public Map upScore1(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore1(score);
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数1上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数1上传失败");
        }
        return map;
    }

    //上传分数2
    @ResponseBody
    @PostMapping("/upscore2")
    public Map upScore2(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore2(score);
        history.setComment1(data.commentList1.get(data.getIndex(score + history.getScore1())));
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数2上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数2上传失败");
        }
        return map;
    }

    //上传分数3
    @ResponseBody
    @PostMapping("/upscore3")
    public Map upScore3(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore3(score);
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数3上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数3上传失败");
        }
        return map;
    }

    //上传分数4
    @ResponseBody
    @PostMapping("/upscore4")
    public Map upScore4(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore4(score);
        history.setComment2(data.commentList2.get(data.getIndex(score + history.getScore3())));
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数4上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数4上传失败");
        }
        return map;
    }

    //上传分数5
    @ResponseBody
    @PostMapping("/upscore5")
    public Map upScore5(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore5(score);
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数5上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数5上传失败");
        }
        return map;
    }

    //上传6
    @ResponseBody
    @PostMapping("/upscore6")
    public Map upScore6(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore6(score);
        history.setComment3(data.commentList3.get(data.getIndex(score + history.getScore5())));
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数6上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数6上传失败");
        }
        return map;
    }

    //上传分数7
    @ResponseBody
    @PostMapping("/upscore7")
    public Map upScore7(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore7(score);
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数7上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数7上传失败");
        }
        return map;
    }

    //上传分数8
    @ResponseBody
    @PostMapping("/upscore8")
    public Map upScore8(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore8(score);
        history.setComment4(data.commentList4.get(data.getIndex(score + history.getScore7())));
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数8上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数8上传失败");
        }
        return map;
    }

    //上传分数9
    @ResponseBody
    @PostMapping("/upscore9")
    public Map upScore9(@RequestParam("id") int id, @RequestParam("score") float score) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setScore9(score);
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数9上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数9上传失败");
        }
        return map;
    }

    //上传分数10
    @ResponseBody
    @PostMapping("/upscore10")
    public Map upScore10(@RequestParam("id") int id) {
        Map map = new HashMap();
        History history = historyService.findById(id);
        history.setId(id);
        history.setFinishTime(new Timestamp(System.currentTimeMillis() + TIME));
        //计算速度的得分
        int timeScore = 0;
        long t1 = (System.currentTimeMillis() + TIME) / 1000;
        long t2 = historyService.findById(id).getStartTime().getTime() / 1000;
        long t = t1 - t2;
        if (t >= 1200) {
            timeScore = 0;
        } else if (t <= 600) {
            timeScore = 100;
        } else {
            timeScore = new Long((1200 - t) / 12).intValue();
        }
        history.setTimescore(timeScore);
        if (historyRepository.save(history) != null) {
            map.put("code", 200);
            map.put("result", "游戏分数10上传成功");
        } else {
            map.put("code", 0);
            map.put("result", "游戏分数10上传失败");
        }
        return map;
    }

}
