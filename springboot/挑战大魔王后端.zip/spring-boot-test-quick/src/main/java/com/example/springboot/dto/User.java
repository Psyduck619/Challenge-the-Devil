package com.example.springboot.dto;

import java.io.Serializable;
import javax.persistence.*;

@Entity//标注位实体类
@Table(name = "user")//对应数据库的表
public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id//主键注解
    @Column(name = "wxid")
    private String wxId; //微信id
    @Column(name = "wxname")
    private String wxName; //微信名称
    @Column(name = "username")
    private String userName;//用户名
    @Column(name = "sex")
    private int sex;//性别
    @Column(name = "age")
    private int age;//年龄

    public User(){}

    public User(String wxId, String wxName, String userName, int sex, int age) {
        this.wxId = wxId;
        this.wxName = wxName;
        this.userName = userName;
        this.sex = sex;
        this.age = age;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getWxId() {
        return wxId;
    }

    public void setWxId(String wxId) {
        this.wxId = wxId;
    }

    public String getWxName() {
        return wxName;
    }

    public void setWxName(String wxName) {
        this.wxName = wxName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
