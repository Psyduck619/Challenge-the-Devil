package com.example.springboot.dao;

import com.example.springboot.dto.IoT;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IoTRepository extends JpaRepository<IoT, String> {

    List<IoT> findAll();

}
