package com.example.springboot.dto;

import javax.persistence.*;

@Entity
@Table(name = "A_attention")
public class AAttention {

    private static final long serialVersionUID = 1L;
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "answer_title")
    private String answerTitle;
    @Column(name = "answer_content")
    private String answerContent;
    @Column(name = "answer_rightnum")
    private int answerRightNum;
    @Column(name = "puzzle")
    private String puzzle;
    @Column(name = "puzzle_margin_bottom")
    private String puzzleMarginBottom;
    @Column(name = "level")
    private int level;

    public AAttention() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAnswerTitle() {
        return answerTitle;
    }

    public void setAnswerTitle(String answerTitle) {
        this.answerTitle = answerTitle;
    }

    public String getAnswerContent() {
        return answerContent;
    }

    public void setAnswerContent(String answerContent) {
        this.answerContent = answerContent;
    }

    public int getAnswerRightNum() {
        return answerRightNum;
    }

    public void setAnswerRightNum(int answerRightNum) {
        this.answerRightNum = answerRightNum;
    }

    public String getPuzzle() {
        return puzzle;
    }

    public void setPuzzle(String puzzle) {
        this.puzzle = puzzle;
    }

    public String getPuzzleMarginBottom() {
        return puzzleMarginBottom;
    }

    public void setPuzzleMarginBottom(String puzzleMarginBottom) {
        this.puzzleMarginBottom = puzzleMarginBottom;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
