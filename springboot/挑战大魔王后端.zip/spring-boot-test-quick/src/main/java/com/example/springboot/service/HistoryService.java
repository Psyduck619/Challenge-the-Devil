package com.example.springboot.service;

import com.example.springboot.dto.History;

import java.util.List;

public interface HistoryService {
    List<History> findAll();
    List<History> findByUserId(String openId);
    History findById(int id);
}
