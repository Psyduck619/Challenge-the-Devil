package com.example.springboot.dao;

import com.example.springboot.dto.AAttention;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AAttentionRepository extends JpaRepository<AAttention, String> {
    List<AAttention> findAll();
}
