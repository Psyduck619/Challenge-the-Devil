package com.example.springboot.dao;

import com.example.springboot.dto.History;
import com.example.springboot.dto.UserComment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserCommentRepository extends JpaRepository<UserComment, String> {
    List<UserComment> findAll();
}
